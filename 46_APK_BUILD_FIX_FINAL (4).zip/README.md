# 46 Android App

This is the Android Studio project for the **46** app.

## GitHub Actions

The included workflow is designed to build a debug APK on GitHub Actions.

- Java 17
- Gradle 8.10.2
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- Java/Kotlin JVM target 17

The app's registration flow is:
1. Name
2. Mobile number + consent notice
3. Successfully Verified after server registration

The app does not implement covert SMS interception or covert call forwarding.
